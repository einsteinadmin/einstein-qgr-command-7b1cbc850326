# Matisen feed templates — Q2 2026 QGR packet
One file per open chase-list row. The moves CSV you sent 7/21 AM is the gold standard — it passed intake validation first try. Match its shape:

1. **Metadata header (# lines) is required**: source system + pull timestamp + date range (end date >= 4 days before pull — no fresher, unsettled data).
2. **Branch keys**: n_austin, s_austin, leander, san_antonio, houston, n_dallas, fort_worth, garland, mckinney, tampa (n_dallas = Dallas).
3. **Blank ≠ zero.** Leave cells empty when not calculable; never type 0 for missing.
4. **Label every basis** ($ vs #, actual vs estimate, definition used). Unlabeled bases get rejected at intake.
5. Return files to Cameron/Albert — Albert runs validate_intake.py, transcribes into the audited manifest with provenance, and re-renders. Please don't edit any manifest JSON directly — the validator + provenance stamps live on Albert's side.
