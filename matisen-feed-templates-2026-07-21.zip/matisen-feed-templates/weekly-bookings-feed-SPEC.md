# Weekly bookings feed — spec (for Ben's 13-week rolling cash forecast; agreed on the 7/21 Prosper call)

Cadence: weekly, dated files, history never overwritten (same convention as the EMMA feed drops).
Format: CSV fine. Columns per branch per week:

week_start,branch,bookings_#,bookings_$,realization_rate_90d_pct,pipeline_booked_future_$

Header must carry: source system, pull timestamp, date range. Ben consumes this directly — deliver wherever the EMMA feed lands, ping Albert on the first drop.
